export const OldTokenAddress = "0xb6c0189080a6441CAF056B856Dd4d795B909C460";
export const newTokenAddress = "0x78069E97C5a1c4a92da4C577DBCfd86CFd83da53";
export const vestingAndClaimAddress =
  "0x5Cfddb08FD369E9D0b70D053324b0C19B0B57D0B";
