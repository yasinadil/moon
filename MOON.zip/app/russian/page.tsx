import Russian from "@/components/Russian/page";
import React from "react";

export default async function page() {
  return <Russian />;
}
