import Home from "@/components/Home/page";
import React from "react";

export default async function page() {
  return <Home />;
}
